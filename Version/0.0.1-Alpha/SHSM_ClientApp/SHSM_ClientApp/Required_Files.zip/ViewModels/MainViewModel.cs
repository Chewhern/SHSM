﻿namespace SHSM_ClientApp.ViewModels;

public partial class MainViewModel : ViewModelBase
{
}
