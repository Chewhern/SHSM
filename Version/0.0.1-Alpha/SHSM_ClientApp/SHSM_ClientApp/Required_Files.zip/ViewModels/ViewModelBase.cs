﻿using CommunityToolkit.Mvvm.ComponentModel;

namespace SHSM_ClientApp.ViewModels;

public class ViewModelBase : ObservableObject
{
}
